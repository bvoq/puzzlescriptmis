How to install puzzlescriptmiswin
=================================

1. Install vcredist_x64_2013.exe (contains vcomp120.dll)
2. Install vcredist_x64_2017.exe (contains other required dll's)
3. Run puzzlescriptmiswin.exe

Make sure that you unzipped everything and didn't change the folder structure.
puzzlescriptmiswin.exe

More information:
If you don't trust my source, you can also google for the installers of the DLLs yourself:
Visual C++ Redistributable Packages for Visual Studio 2013
Visual C++ Redistributable Packages for Visual Studio 2017

If you already have Visual Studio installed you might be able to already run puzzlescriptmiswin.exe without needing to install these.